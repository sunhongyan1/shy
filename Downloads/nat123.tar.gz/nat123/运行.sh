cd /etc/nat123
sudo mono nat123linux.sh
