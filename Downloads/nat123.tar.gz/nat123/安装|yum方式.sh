cat ./source/liblink.so
sleep 3
sudo yum update
sudo yum install mono-complete
sudo yum install screen
sudo mkdir /etc/nat123
sudo chmod 777 /etc/nat123
sudo cp ./source/program/* /etc/nat123
sleep 1
cat ./source/mono-installer.so
sleep 2
sudo screen -S nat123
