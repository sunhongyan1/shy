var searchData=
[
  ['pfunc_5fbcon_5fadapter_5fdiscovery_5fcallback',['PFUNC_BCON_ADAPTER_DISCOVERY_CALLBACK',['../_bcon_adapter_enumerator_8h.html#adcf9ebf2305d5aa585647b3de9af8ef7',1,'BconAdapterEnumerator.h']]]
];
