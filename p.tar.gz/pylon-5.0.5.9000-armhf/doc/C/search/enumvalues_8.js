var searchData=
[
  ['linear',['Linear',['../group__genapi.html#ggac5128bced9072f8bc7b1c717ee7fc38ba1a1f3bc55fefa098d9034cc46e2e7a2b',1,'GenApiCEnums.h']]],
  ['logarithmic',['Logarithmic',['../group__genapi.html#ggac5128bced9072f8bc7b1c717ee7fc38ba4323cea6724855c28713ade15dfaaee9',1,'GenApiCEnums.h']]]
];
