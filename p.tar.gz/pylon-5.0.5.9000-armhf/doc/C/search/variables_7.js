var searchData=
[
  ['offsetx',['OffsetX',['../struct_pylon_grab_result__t.html#ac2bea85513262a1b800afd09301d2000',1,'PylonGrabResult_t']]],
  ['offsety',['OffsetY',['../struct_pylon_grab_result__t.html#ab8385ee4e8e891d33216bc6eba8851b6',1,'PylonGrabResult_t']]]
];
