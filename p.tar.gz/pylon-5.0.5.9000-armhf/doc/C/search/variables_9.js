var searchData=
[
  ['quality',['quality',['../struct_pylon_image_persistence_options__t.html#a3661a9c93a0c6a5e61bf86c6baaaf23b',1,'PylonImagePersistenceOptions_t']]]
];
