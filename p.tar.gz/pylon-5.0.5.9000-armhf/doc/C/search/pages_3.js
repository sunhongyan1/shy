var searchData=
[
  ['software_20licensing_20and_20legal_20information',['Software Licensing and Legal Information',['../licensing.html',1,'index']]],
  ['sample_20programs',['Sample Programs',['../samples.html',1,'index']]]
];
