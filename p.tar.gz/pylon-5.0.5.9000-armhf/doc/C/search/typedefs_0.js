var searchData=
[
  ['genapi_5ffile_5fhandle',['GENAPI_FILE_HANDLE',['../group__genapi.html#gaeb921b573acb9ef15b748e7227ee6ec7',1,'GenApiC.h']]]
];
