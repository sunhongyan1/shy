var searchData=
[
  ['blockid',['BlockID',['../struct_pylon_grab_result__t.html#a78a42cc71382f7a58e15cf33040a0566',1,'PylonGrabResult_t']]],
  ['buffer',['Buffer',['../struct_pylon_event_result__t.html#a27d49f24d5ef7ba644e8f0d9fd42d5f5',1,'PylonEventResult_t']]]
];
