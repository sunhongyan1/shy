var searchData=
[
  ['errorcode',['ErrorCode',['../struct_pylon_grab_result__t.html#a597c9f0ddc8e7a63df7e108441e9bd78',1,'PylonGrabResult_t::ErrorCode()'],['../struct_pylon_event_result__t.html#ad7fa25f406eda20ec22679caf86a6fb8',1,'PylonEventResult_t::ErrorCode()']]]
];
